import re

def parse_data_file(file_path):
    data = {}
    current_region = None
    
    with open(file_path, 'r', encoding='utf8') as file:
        for line in file:
            if line.startswith("場域:"):
                current_region = line.split("場域:")[1].strip()
                data[current_region] = []
            else:
                # 使用正則表達式解析每行内容
                match = re.match(r'([\w\d]+)\/([\w\d]+)\/(\w+)\/(\d+)%\/(\d+)次', line.strip())
                if match:
                    machine_id, device_code, location, downtime_percentage, _ = match.groups()
                    downtime_percentage = int(downtime_percentage)
                    data[current_region].append((machine_id, device_code, location, downtime_percentage))
    
    return data

def calculate_disconnect_percentage_per_hour(data):
    output = {}
    hours_in_day = 24  # 24 hours in a day
    minutes_per_hour = 60  # 60 minutes per hour
    
    for region, devices in data.items():
        output[region] = []
        for device in devices:
            machine_id, device_code, location, downtime_percentage = device
            total_disconnect_hours = (downtime_percentage / 100) * hours_in_day
            
            hourly_disconnect = []
            for hour in range(hours_in_day):
                hourly_disconnect.append((machine_id, device_code, location, total_disconnect_hours))
            
            output[region] += hourly_disconnect
    return output

# 讀取和解析數據
file_path = 'data.txt'
data = parse_data_file(file_path)

# 按小時計算斷線時間佔比
result = calculate_disconnect_percentage_per_hour(data)

# 輸出結果
for region, devices in result.items():
    print(f"場域: {region}")
    for device in devices:
        machine_id, device_code, location, hourly_disconnect = device
        print(f"機台: {machine_id}, 地點: {location}, 每小時斷線時間（小時佔比）: {hourly_disconnect}")
